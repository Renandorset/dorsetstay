import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import {
  BrowserRouter,
  createBrowserRouter,
  createRoutesFromElements,
  Route,
  RouterProvider,
} from "react-router-dom";
// Pages start from here
import Login from './Components/Login.jsx';
import Signup from './Components/Signup.jsx';
import Home from './Pages/Home.jsx';
import CreateListing from './Pages/CreateListing.jsx';
import UpdateListing from './Pages/UpdateListing.jsx';
import AboutUs from './Pages/AboutUs.jsx';
import UpdateAboutUs from './Pages/UpdateAboutUs.jsx';
import ShowService from './Pages/ShowService.jsx';
import UserAboutUs from './Pages/UserAboutUs.jsx';
import UpdateUserAboutUs from './Pages/UpdateUserAboutUs.jsx';
import DoctorDetails from './Pages/DoctorDetails.jsx';
import BookedService from './Pages/BookedService.jsx';
import ShowRequest from './Pages/ShowRequest.jsx';
import CompleteRequest from './Pages/CompleteRequest.jsx';
import CompleteBooking from './Pages/CompleteBooking.jsx';
// This is  layout sections
import Layout1 from './Layout/Layout1.jsx';
import Layout2 from './Layout/Layout2.jsx';


// react redux
import { Provider } from 'react-redux';
import store from './Redux/store.js';
// import { PersistGate } from "redux-persist/integration/react";


const router = createBrowserRouter(
  createRoutesFromElements(
    <>
      <Route path="/" element={<Signup />} />
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      
      <Route path="/main" element={<Layout1 />}>
        <Route path="" element={<Home />} />
        <Route path='about' element={<UserAboutUs/>}/>
        <Route path='updateabout' element={<UpdateUserAboutUs/>}/>
        <Route path='doctor' element={<DoctorDetails/>}/>
        <Route path='booked' element={<BookedService/>}/>
        <Route path='complete' element={<CompleteBooking/>}/>
      </Route>
      <Route path='/service' element={<Layout2 />} >
        <Route path='' element={<ShowService/>} />
        <Route path='create' element={<CreateListing />} />
        <Route path='update' element={<UpdateListing />} />
        <Route path='about' element={<AboutUs />} />
        <Route path='updateabout' element={<UpdateAboutUs />}/>
        <Route path='show' element={<ShowService />} />
        <Route path='request' element={<ShowRequest />} />
        <Route path='complete' element={<CompleteRequest />} />
      </Route>
    </>
  )
);
createRoot(document.getElementById('root')).render(
  <StrictMode>
    <Provider store={store}>
   
    
    <RouterProvider router={router} />
    </Provider>
  </StrictMode>,
)
