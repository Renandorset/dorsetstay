import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import "./ShowService.css";

export default function ShowRequest() {
  const email1 = useSelector((state) => state.slice.email);
  console.log(email1);

  const [services, setServices] = useState([]);

  const getData = async () => {
    let result = await fetch(
      `http://127.0.0.1:8000/api/servicelistings/?search=${email1}`
    );
    let data1 = await result.json();
    return data1;
  };

  useEffect(() => {
    getData().then((data1) => {
      console.log(data1);
      setServices(data1);
    });
  }, []);

  const method = async (id) => {
    let sd = `http://127.0.0.1:8000/api/servicelistings/${id}/`;
    let result = await fetch(sd);
    let data = await result.json();
    return data;
  };

  const method1 = async (id, data) => {
    let sd = `http://127.0.0.1:8000/api/servicelistings/${id}/`;
    let result = await fetch(sd, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(data),
    });
    let result1 = await result.json();
    return result1;
  };

  const handleConfirm = (id) => {
    method(id).then((data) => {
      // Update the service object
      data.confirmation = true;
      data.booking = true;
      data.availability = false;

      // Send the updated data to the backend
      method1(id, data).then((updatedData) => {
        console.log(updatedData);
        alert("Transaction Confirmed");
        // Optionally, update the local state to reflect the changes
        setServices((prevServices) =>
          prevServices.map((service) =>
            service.id === id ? { ...service, confirmation: true } : service
          )
        );
      });
    });
  };

  return (
    <div className="show-service-container">
      <h2>Requested Properties</h2>
      <div className="service-cards">
        {services
          .filter(
            (service) =>
              service.customer !== null && service.confirmation !== true
          ) // Filter services where customer is not null
          .map((service) => (
            <div key={service.id} className="service-card">
              <h3>{service.name}</h3>
              <p>
                <strong>Charges:</strong> {service.charges}
              </p>
              <p>
                <strong>Contact:</strong> {service.contact}
              </p>
                <p>
                    <strong>Customer:</strong> {service.customer}
                </p>
              <p>
                <strong>Description:</strong> {service.description}
              </p>
              <p>
                <strong>Location:</strong> {service.location}
              </p>
              <button
                className="confirm-button"
                onClick={() => handleConfirm(service.id)}
              >
                Confirm Transaction
              </button>
           
            </div>
          ))}
      </div>
    </div>
  );
}
