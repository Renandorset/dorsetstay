import React,{useEffect,useState} from 'react';
import { useNavigate } from 'react-router-dom';
import './AboutUs.css';

import { useSelector } from 'react-redux';


export default function AboutUs() {
console.log("about us page")

const email1 = useSelector((state) => state.slice.email);
const password1 = useSelector((state) => state.slice.password);


const[email,setEmail]=useState(email1);
const[password,setPassword]=useState(password1);
  const navigate = useNavigate();
  const [data1,setData]=useState(null);
  const getData = async () => {
    const endpoint = `http://127.0.0.1:8000/api/users/?email=${email}&password=${password}`;
    let result=await fetch(endpoint);
    let data=await result.json();
    console.log(data);
    return data;
  }

  useEffect(()=>{
    getData().then((data)=>{
      // console.log(data);
      setData(data);
    })
},[])



  const handleUpdateClick = () => {
    navigate('/service/updateabout');
  };

  return (
    <div className="about-us-container">
      <h2>About Us</h2>
      <div className="about-us-details">
      {data1?
      <div> 
        <p><strong>Name:</strong>{data1.email} </p>
        <p><strong>Username:</strong> {data1.username}</p>
        <p><strong>password</strong> {data1.password}</p>
        <p><strong>id</strong> {data1.id}</p>
        {/* <p><strong>Service Description:</strong> Experienced child care provider offering a safe and nurturing environment for children.</p> */}
      </div>:
      null
}
      </div>
      <button className="update-button" onClick={handleUpdateClick}>
        Update About Us
      </button>
    </div>
  );
}