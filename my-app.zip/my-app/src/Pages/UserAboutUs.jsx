import React from 'react';
import { useNavigate } from 'react-router-dom';
import './UserAboutUs.css';

export default function UserAboutUs() {
  const navigate = useNavigate();

  const handleUpdateClick = () => {
    navigate('/main/updateabout');
  };

  return (
    <div className="user-about-us-container">
      <h2>User About Us</h2>
      <div className="user-about-us-details">
        <p><strong>Name:</strong> Jane Doe</p>
        <p><strong>Username:</strong> janedoe123</p>
        <p><strong>Email:</strong> janedoe@example.com</p>
        <p><strong>Location:</strong> 456 Elm Street, Townsville</p>
      </div>
      <button className="update-button" onClick={handleUpdateClick}>
        Update User Info
      </button>
    </div>
  );
}