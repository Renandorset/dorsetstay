import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './CompleteBooking.css';
import { useSelector,useDispatch } from 'react-redux';
import { addId } from '../Redux/slice';

export default function CompleteBooking() {

const email = useSelector((state) => state.slice.email);
const password = useSelector((state) => state.slice.password);
// const id = useSelector((state) => state.id);
console.log(email);
console.log(password);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [doctors, setDoctors] = useState(null);
  let getData = async () => { 
    let result=await fetch("http://127.0.0.1:8000/api/servicelistings");
    let data=await result.json();
    return data;
  }
  
  useEffect(()=>{
    getData().then((data)=>{
      console.log(data);
      setDoctors(data);
    })

  },[])


  // Sample data for doctors (this would typically come from a database or API)

 
  return (
    <div className="show-doctors-container">
      <h2>Completed Booking</h2>
      <div className="doctor-tiles">
      {doctors &&
  doctors
    .filter((doctor) => doctor.confirmation===true && doctor.customer===email) // Filters doctors with availability set to false
    .map((doctor) => (
      <div key={doctor.id} className="doctor-tile">
        <div className="doctor-info">
          <h3>{doctor.name}</h3>
          <img src={doctor.url || "https://media.istockphoto.com/id/1145780239/photo/dark-interior-with-open-kitchen.jpg?s=1024x1024&w=is&k=20&c=sblj5Fh1RL45NxXJEwTdoSLrexewg6uFbdg_NWvrXXw="} alt="Doctor" className="doctor-image" />
          <p>
            <strong>Description:</strong> {doctor.description || "no servicecare provider"}
          </p>
          <p>
            <strong>Location:</strong> {doctor.location || "location not found"}
          </p>
          <p>
            <strong>Price:</strong> {doctor.charges || "charges not found"}
          </p>
        </div>
      
      </div>
    ))}
      </div>
    </div>
  );
}