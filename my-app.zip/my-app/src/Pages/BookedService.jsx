import React, { useState,useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import './ShowDoctors.css';
import { useSelector,useDispatch } from 'react-redux';
import { addId } from '../Redux/slice';

export default function BookedService() {

const email = useSelector((state) => state.slice.email);
const password = useSelector((state) => state.slice.password);
// const id = useSelector((state) => state.id);
console.log(email);
console.log(password);

  const navigate = useNavigate();
  const dispatch = useDispatch();
  const [doctors, setDoctors] = useState(null);
  let getData = async () => { 
    let result=await fetch("http://127.0.0.1:8000/api/servicelistings");
    let data=await result.json();
    return data;
  }
  
  useEffect(()=>{
    getData().then((data)=>{
      console.log(data);
      setDoctors(data);
    })

  },[])


  // Sample data for doctors (this would typically come from a database or API)

  const method=async(id)=>{
    let result=await fetch(`http://127.0.0.1:8000/api/servicelistings/${id}/`);
    let data=await result.json();
    return data; 
  }

  const method1=async(id,data)=>{
    let result=await  fetch(`http://127.0.0.1:8000/api/servicelistings/${id}/`,{
        method:"PUT",
        headers:{
          "Content-Type":"application/json"
        },
        body:JSON.stringify(
          data
        )
    })
    let result1=await result.json();
    return result1;
  }
  const handleViewDetails = (id) => {
    
    method(id).then((data)=>{
        data.booking=false;
        data.availability=true;
        data.customer=null;
        method1(id,data).then((data)=>{
            console.log(data);
            navigate("/main");
        });
    })



 

  };

  return (
    <div className="show-doctors-container">
      <h2>Booked Services</h2>
      <div className="doctor-tiles">
      {doctors &&
  doctors
    .filter((doctor) => doctor.availability === false && doctor.confirmation===false) // Filters doctors with availability set to false
    .map((doctor) => (
      <div key={doctor.id} className="doctor-tile">
        <div className="doctor-info">
          <h3>{doctor.name}</h3>
          <p>
            <strong>Description:</strong> {doctor.description || "no servicecare provider"}
          </p>
          <p>
            <strong>Location:</strong> {doctor.location || "location not found"}
          </p>
          <p>
            <strong>Price:</strong> {doctor.charges || "charges not found"}
          </p>
        </div>
        <div className="doctor-actions">
          <button
            className="view-details-button"
            onClick={() => handleViewDetails(doctor.id)}
          >
            remove Booking
          </button>
        </div>
      </div>
    ))}
      </div>
    </div>
  );
}