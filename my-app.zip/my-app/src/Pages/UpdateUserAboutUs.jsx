import React, { useState } from 'react';
import './UpdateUserAboutUs.css';

export default function UpdateUserAboutUs() {
  // Pre-filled data for the user (this would typically come from a database or API)
  const [formData, setFormData] = useState({
    name: 'Jane Doe',
    username: 'janedoe123',
    email: 'janedoe@example.com',
    location: '456 Elm Street, Townsville',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Updated User Info:', formData);
    alert('User Information Updated Successfully!');
    // Here, you would typically send the updated data to the server
  };

  return (
    <div className="update-user-about-us-container">
      <h2>Update User Information</h2>
      <form className="update-user-about-us-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="username">Username</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            placeholder="Enter your username"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="location">Location</label>
          <input
            type="text"
            id="location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="Enter your location"
            required
          />
        </div>
        <button type="submit" className="submit-button">Update Info</button>
      </form>
    </div>
  );
}