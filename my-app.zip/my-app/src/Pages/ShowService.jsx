import React, { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import './ShowService1.css';

export default function ShowService() {
  const email1 = useSelector((state) => state.slice.email);
  console.log(email1);




  // Sample data for services (this would typically come from a database or API)
  const [services, setServices] = useState([
    {
      id: 1,
      name: 'John Doe',
      description: 'Experienced child care provider offering a safe and nurturing environment.',
      location: '123 Main Street, Cityville',
    },
    {
      id: 2,
      name: 'Jane Smith',
      description: 'Professional child care services with flexible timings.',
      location: '456 Elm Street, Townsville',
    },
    {
      id: 3,
      name: 'Emily Johnson',
      description: 'Affordable and reliable child care services for working parents.',
      location: '789 Oak Avenue, Suburbia',
    },
  ]);

// const [data,setData]=useState(null);
const getData = async () => { 
  let result=await fetch(`http://127.0.0.1:8000/api/servicelistings/?search=${email1}`);
  let data1=await result.json();
  return data1;
}  
useEffect(()=>{
  getData().then((data1)=>{
    console.log(data1);
    // setData(data1);
    console.log(data1);
    setServices(data1);
  })
},[])


  const handleConfirm = (id) => {
    alert(`Transaction confirmed for service ID: ${id}`);
  };

  return (
    <div className="show-service-container">
      <h2>Available Properties </h2>
      <div className="service-cards">
      {services
  .filter((service) => service.customer === null) // Filter services where customer is null
  .map((service) => (
    <div key={service.id} className="service-card">
      <h3>{service.name}</h3>
      <img src={service.url || "https://media.istockphoto.com/id/1145780239/photo/dark-interior-with-open-kitchen.jpg?s=1024x1024&w=is&k=20&c=sblj5Fh1RL45NxXJEwTdoSLrexewg6uFbdg_NWvrXXw="} alt="Service" className="service-image" />
      <p><strong>Description:</strong> {service.description}</p>
      <p><strong>Location:</strong> {service.location}</p>
      <p><strong>Charges:</strong> {service.charges}</p>
      <p><strong>Contact:</strong> {service.contact}</p>
      <p><strong>Timing:</strong> {service.timing}</p>
    </div>
  ))}
      </div>
    </div>
  );
}