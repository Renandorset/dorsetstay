import React, { useState } from 'react';
import './UpdateListing.css';

export default function UpdateListing() {
  // Pre-filled data for the listing (this would typically come from a database or API)
  const [formData, setFormData] = useState({
    name: 'John Doe',
    description: 'Experienced child care provider with a safe and nurturing environment.',
    location: '123 Main Street, Cityville',
    contact: '123-456-7890',
    timing: '9 AM - 5 PM',
    charges: '$50/hour',
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Listing Updated:', formData);
    alert('Child Care Listing Updated Successfully!');
    // Here, you would typically send the updated data to the server
  };

  return (
    <div className="update-listing-container">
      <h2>Update Child Care Listing</h2>
      <form className="update-listing-form" onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="name">Service Provider Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="description">Description</label>
          <textarea
            id="description"
            name="description"
            value={formData.description}
            onChange={handleChange}
            placeholder="Describe the child care service"
            rows="4"
            required
          ></textarea>
        </div>
        <div className="form-group">
          <label htmlFor="location">Location</label>
          <input
            type="text"
            id="location"
            name="location"
            value={formData.location}
            onChange={handleChange}
            placeholder="Enter your location"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="contact">Contact Information</label>
          <input
            type="text"
            id="contact"
            name="contact"
            value={formData.contact}
            onChange={handleChange}
            placeholder="Enter your contact details"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="timing">Timing of Availability</label>
          <input
            type="text"
            id="timing"
            name="timing"
            value={formData.timing}
            onChange={handleChange}
            placeholder="Enter available timings (e.g., 9 AM - 5 PM)"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="charges">Charges</label>
          <input
            type="text"
            id="charges"
            name="charges"
            value={formData.charges}
            onChange={handleChange}
            placeholder="Enter charges (e.g., $50/hour)"
            required
          />
        </div>
        <button type="submit" className="submit-button">Update Listing</button>
      </form>
    </div>
  );
}