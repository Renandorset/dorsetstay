
import React from 'react'
import { Outlet } from 'react-router-dom'
import Navbar1 from '../Components/Navbar1';

export default function Layout2() {
  return (
    <>

   <Navbar1/>
    <Outlet/> 
    </>
 );
}
