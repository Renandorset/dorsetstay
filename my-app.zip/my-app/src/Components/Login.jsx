import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";
import { useDispatch, useSelector } from "react-redux";
import { addCredentials } from "../Redux/slice";

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const dispatch = useDispatch();

  let getData = async () => {
    const endpoint = `http://127.0.0.1:8000/api/users/?email=${email}&password=${password}`;
    let resp = await fetch(endpoint);
    let data = await resp.json();
    return data;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Email:", email);
    console.log("Password:", password);

    getData().then((data) => {
      console.log(data);
      if (data.name && data.email) {
        dispatch(addCredentials({ email: email, password: password }));

        if (data.serviceProvider==false) {
          navigate("/main");
        } else {
          navigate("/service");
        }
      } else {
        alert("Invalid email or password");
      }
    });
  };

  return (
    <div className="login-container">
      <form className="login-form">
        <h2 className="login-title">Login</h2>
        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="Enter your email"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Enter your password"
            required
          />
        </div>
        <button
          onClick={(e) => {
            handleSubmit(e);
          }}
          className="login-button"
        >
          Login
        </button>
        <button
          type="submit"
          className="signup-button"
          onClick={(e) => {
            e.preventDefault();
            navigate("/signup");
          }}
        >
          Dont have an account? Signup
        </button>
      </form>
    </div>
  );
}

export default Login;
