import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  return (
    <nav className="navbar">
      {/* Left Section */}
      <div className="navbar-left">
        <Link to="/main" className="navbar-link">Home</Link>
      </div>

      {/* Middle Section */}
      <div className="navbar-middle">
        <Link to="/main/booked" className="navbar-link">booked services</Link>
        <Link to="/main/complete" className="navbar-link">Booking Complete</Link>
       
      </div>

      {/* Right Section */}
      <div className="navbar-right">
        <Link to="/login" className="navbar-link">Log Out</Link>
      </div>
    </nav>
  );
}