import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar1.css';

export default function Navbar1() {
  return (
    <nav className="navbar1">
      {/* Left Section */}
      <div className="navbar1-left">
        <Link to="/service/create" className="navbar1-link">Create Listing</Link>
      </div>

      {/* Middle Section */}
      <div className="navbar1-middle">
        <Link to="/service/show" className="navbar1-link">Show Services</Link>
      </div>
      <div className="navbar1-middle">
        <Link to="/service/request" className="navbar1-link">Show request</Link>
      </div>
      <div className="navbar1-middle">
        <Link to="/service/complete" className="navbar1-link">Complete Request</Link>
      </div>
      {/* Right Section */}
      <div className="navbar1-right">
        <Link to="/service/about" className="navbar1-link">About Us</Link>
      </div>
    </nav>
  );
}