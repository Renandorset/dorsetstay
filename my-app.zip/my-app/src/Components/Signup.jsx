import React, { useState } from "react";
import "./Signup.css";
import { useNavigate } from "react-router-dom";

function Signup() {
  let sd = "http://127.0.0.1:8000/api/users/";

  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    username: "",
    serviceProvider: false,
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const method = async () => {
    let res = await fetch(sd, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });
    let data = await res.json();

    console.log(data);
    return data;
  }
  const handleSubmit = (e) => {
    e.preventDefault();
    method().then((data) => {
      console.log(data);
      if (data.id) {
        alert("Signup Successful!");
        navigate("/login"); // Redirect to login page after successful signup
      } else {
        alert("Failed to create account. Please try again.");
      }
      // Reset form 


    })
  
  };

  return (
    <div className="signup-container">
      <form className="signup-form" onSubmit={handleSubmit}>
        <h2 className="signup-title">Signup</h2>
        <div className="form-group">
          <label htmlFor="name">Name</label>
          <input
            type="text"
            id="name"
            name="name"
            value={formData.name}
            onChange={handleChange}
            placeholder="Enter your name"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="username">User name</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formData.username}
            onChange={handleChange}
            placeholder="Enter your username"
            required
          />
        </div>


        <div className="form-group">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="Enter your email"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="Enter your password"
            required
          />
        </div>
        <div className="form-group">
          <label htmlFor="serviceProvider">Are you a Service Provider?</label>
          <input
            type="checkbox"
            id="serviceProvider"
            name="serviceProvider"
            checked={formData.serviceProvider} // Use `checked` for checkboxes
            onChange={
              (e) =>
                setFormData({ ...formData, serviceProvider: e.target.checked }) // Update state with true/false
            }
          />
        </div>
        <button type="submit" className="signup-button">
          Signup
        </button>
        <button
          onClick={(e) => {
            e.preventDefault();
            navigate("/login");
          }}
          type="button"
          className="login-button"
        >
          Login instead
        </button>
      </form>
    </div>
  );
}

export default Signup;
